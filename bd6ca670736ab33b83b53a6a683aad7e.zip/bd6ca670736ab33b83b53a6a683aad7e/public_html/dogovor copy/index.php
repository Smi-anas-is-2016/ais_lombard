
<?php
if (!empty($_COOKIE['sid'])) {session_id($_COOKIE['sid']);}
session_start();
require_once 'classes/Auth.class.php';
require_once 'stayt.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>Главная страница</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="stylees.css">
</head>

<body>

<?php if (Auth\User::isAuthorized()): ?>
 <header>
        <div class="logo">
            <a href="index.html"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Главная</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="contact.html">Договора</a>
                <a href="about.html">Локация</a>
                <a href="services.html">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>

<div class="omus">

<script type="text/javascript"> function displ(ddd) { if (document.getElementById(ddd).style.display == 'none') {document.getElementById(ddd).style.display = 'block'} else {document.getElementById(ddd).style.display = 'none'} } </script>

<div id="var222" style="display: none;">


</div><a href="javascript: displ('var222')"></a></div>
<form novalidate="novalidate" class="form-signin ajax" method="post" action=
"ajax.php">
    
         <nav>
             <h1>Договор</h1> 

<p><a href='orderformadd.php'>Внести договор в базу</a> 
<p><a href='../index.php'>На главную</a> 
            <?php 
require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 
//$query="SELECT * FROM predmet, klient WHERE predmet.idpred > klient.idkl";

  
$query ="SELECT * FROM predmet"; 
$result = $handle->query($query); 
$numresult=$result->num_rows; 


//echo '<p>Количество записей - '.$numresult; 


echo '<table border=1>'; 
echo '<tr><th>№ </th>'; 
echo '<th>Предмет</th>'; 
echo '<th>Вес</th>'; 
echo '<th>Наличие камней</th>'; 
echo '<th>Металл</th>'; 
echo '<th>Проба</th>'; 
    
$query ="SELECT * FROM klient"; 
$result = $handle->query($query); 
$numresult=$result->num_rows; 



echo '<th>Фамилия</th>'; 
echo '<th>Имя</th>'; 
echo '<th>Отчество</th>'; 
echo '<th>Паспортные данные</th>'; 
echo '<th>Телефон</th>'; 

 for ($i=0;$i<$numresult;$i++) 
{ 
$row=$result->fetch_assoc(); 
echo '<tr><td>'.$row['idpred']; 
echo '</td><td>'.$row['pred']; 
echo '</td><td>'.$row['ves']; 
echo '</td><td>'.$row['kamn']; 
echo '</td><td>'.$row['metall']; 
echo '</td><td>'.$row['proba']; 

echo '</td><td>'.$row['fam']; 
echo '</td><td>'.$row['im']; 
echo '</td><td>'.$row['otch']; 
echo '</td><td>'.$row['pasp']; 
echo '</td><td>'.$row['tel']; 

echo '<th></th>'; 
echo '<th></th>'; 



echo '</td><td>'; 
echo '<form action="delorder.php" method="post">'; 
echo '<input type="hidden" name="idpred" value="'.$row['idpred'].'">'; 
echo '<input type="submit" value="Удалить">'; 
echo '</form>'; 
echo '</td><td>'; 
echo '<form action="orderformedit.php" method="post">'; 
echo '<input type="hidden" name="idpred" value="'.$row['idpred'].'">'; 
echo '<input type="submit" value="Изменить">'; 
echo '</form>'; 
} 
echo '</table>'; 

mysqli_close($handle); 

$res = mysql_query("
     SELECT klient.fam,
          klient.im,
            predmet.pred,
                predmet.ves
     FROM
            klient,predmet
     WHERE 
           klient.fam =
            predmet.pred;") or die(mysql_error());





$query = mysql_fetch_array(mysql_query("SELECT * FROM `klient`"));

$result = $handle->query($query); 
$numresult=$result->num_rows; 

// теперь у нас есть массив с данными из ячеек name и lastname
// далее заполняем нашу html-таблицу
echo "<table>";
echo '<table border=1>'; 
echo '<th>№</th>'; 
echo '<th>Фамилия</th>'; 
echo '<th>Имя</th>'; 
echo '<th>Отчество</th>'; 
echo '<th>Паспортные данные</th>'; 
echo '<th>Телефон</th>'; 
echo '<th>№</th>'; 
echo '<th>Предмет</th>'; 
echo '<th>Вес</th>'; 
echo '<th>Наличие камней</th>'; 
echo '<th>Металл</th>'; 
echo '<th>Проба</th>'; 

   echo "<tr>";
     echo "<td>".$query['idkl']."</td>"; 
      echo "<td>".$query['fam']."</td>"; // сюда вставим значение name
      echo "<td>".$query['im']."</td>"; 
        echo "<td>".$query['otch']."</td>"; 
          echo "<td>".$query['pasp']."</td>"; 
            echo "<td>".$query['tel']."</td>"; 
    $query= mysql_fetch_array(mysql_query("SELECT * FROM `predmet`"));
     $result = $handle->query($query); 
$numresult=$result->num_rows; 

     
       echo "<td>".$query['idpred']."</td>";
              echo "<td>".$query['pred']."</td>";
              echo "<td>".$query['ves']."</td>";
              echo "<td>".$query['kamn']."</td>";
              echo "<td>".$query['metall']."</td>";
                 echo "<td>".$query['proba']."</td>";
              

   echo "</td>";
   
echo "</table>";







$result = mysql_query("SELECT * FROM  predmet");
 $row = $handle->query($query); 
$numresult=$row->num_rows; 

echo '<table border=1>'; 
echo '<th>№</th>'; 
echo '<th>Предмет</th>'; 
echo '<th>Вес</th>'; 
echo '<th>Наличие камней</th>'; 
echo '<th>Металл</th>'; 
echo '<th>Проба</th>'; 


   echo "<tr>";
while ($row=mysql_fetch_array($result)){
 
        
       echo "<td>".$row['idpred']."</td>";
              echo "<td>".$row['pred']."</td>";
              echo "<td>".$row['ves']."</td>";
              echo "<td>".$row['kamn']."</td>";
              echo "<td>".$row['metall']."</td>";
                 echo "<td>".$row['proba']."</td>";
}
echo '<th></th>'; 

echo '<th></th>'; 
echo '<th></th>'; 




echo "</table>";



?>













<input type="button" value="Информация о клиентах" onclick="javascript:window.location='predmet/index.php'"/>

<input type="hidden" name="act" value="logout">
<input type="submit" class="vyxod" value="Выйти" /></form></div><?php else: ?>




 <?php endif; ?>


  <script src="script.js"></script>
<script type="text/javascript" src="jquery-2.0.3.min.js"></script><script type="text/javascript" src="ajax-form.js"></script></body></html>