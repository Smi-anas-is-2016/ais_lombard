<html> 
<head> 
<title>Внести клиента</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
</head> 
<body> 
<h1>Внести клиента</h1> 
<p><a href='index.php'>Список клиентов</a> 
<h2>Форма заполнения</h2> 
<form action="processorderadd.php" method=post> 
<table border=0> 
<tr bgcolor=#cccccc> 
 <tr> 

<td>Фамилия
<td align=left><input type="text" name="fam" size=60 maxlength=60 required>
   <tr> 

<td>Имя
<td align=left><input type="text" name="im" size=60 maxlength=60 required>
   <tr> 
<td>Отчетсво
<td align=left><input type="text" name="otch" size=60 maxlength=60 required>
   <tr> 

<td>Паспорт
<td align=left><input type="text" name="pasp" size=60 maxlength=60 required>
   <tr> 
<td>Телфон
<td align=left><input type="text" name="tel" size=60 maxlength=60 required>
   <tr> 
<tr> 
<td>Предмет
<td align=left><input type="text" name="pred" size=60 maxlength=60 required> 
<tr> 
<td>Вес
<td align=left><input type="text" name="ves" size=60 maxlength=60 required>

<tr>
<td>Наличие камней
<td align=left><input type="text" name="kamn" size=60 maxlength=60 required>
<tr>
<td>Металл
<td align=left><input type="text" name="metall" size=60 maxlength=60 required>
<tr>
<td>Проба
<td align=left><input type="text" name="proba" size=60 maxlength=60 required>
  
  
  <tr>
<td>Дата заказа
<td align=left><input type="text" name="dataz" size=60 maxlength=60 required>
<tr>
<td>Сумма заказа
<td align=left><input type="text" name="sumzal" size=60 maxlength=60 required>
<tr>
<td>Сумма займа
<td align=left><input type="text" name="sumzaima" size=60 maxlength=60 required>
  
<td>Срок
<td align=left><input type="text" name="srok" size=60 maxlength=60 required>
  


<td colspan=2 align=center><input type=submit value="Внести"></td> 
</table> 
</form> 
</body> 
</html>