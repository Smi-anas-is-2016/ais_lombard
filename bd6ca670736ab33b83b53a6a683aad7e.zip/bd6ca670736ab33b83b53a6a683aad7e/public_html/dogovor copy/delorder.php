<html> 
<head> 
<title>"Web-программирование" (Александров А.В) - Работа 6
</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
</head> 
<body> 

<h1>Анкета студента(база данных)</h1> 
<h2>Удаление анкеты</h2> 
<?php 


$query ="SELECT * FROM predmet"; 


$idpred= $_REQUEST['idpred']; 

require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 

$query = "DELETE FROM predmet WHERE idpred=$idpred"; 
$result = $handle->query($query); 
if ($result) echo "Данные удалены"; 
if (!$result) echo "Ошибка удаления данных"; 
echo "<p><a href='index.php'>Cписок блюд</a>"; 
mysqli_close($handle); 
?> 
</body> 
</html>