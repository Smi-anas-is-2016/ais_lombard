<?php
if (!empty($_COOKIE['sid'])) {session_id($_COOKIE['sid']);}
session_start();
require_once 'classes/Auth.class.php';
require_once 'stayt.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    	
<meta name="robots" content="noindex,follow" />
<meta charset="utf-8"><meta name="yandex-verification" content="d0cd20a4138667e1" />
<title>Главная страница</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css?v=3.4.2">
 <link rel="shortcut icon" href="https://img2.pngindir.com/20180330/ggw/kisspng-light-yagami-letter-alphabet-clip-art-l-5abdf8c81fe3f9.0592132715223994321306.jpg" type="image/x-icon">
 <link rel="stylesheet" type="text/css" href="stylees.css?v=3.4.2">
</head>

<body>

  
<?php if (Auth\User::isAuthorized()): ?>

 <header>
        <div class="logo">
            <a href="index.html"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



   
    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="index.php">Главная</a>
                <a href="klient/index.php">Клиенты</a>
                <a href="predmet/index.php">Предметы</a>
                <a href="dogovor/index.php">Договора</a>
                <a href="pray/index.php">Прайс</a>
                <a href="katalog/index.php">Каталог</a>
            
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>

<div class="omus">
<?php echo "<p class='privet'>Здравствуй, <span>".$arr['names']."</span>!</p>";?>
<script type="text/javascript"> function displ(ddd) { if (document.getElementById(ddd).style.display == 'none') {document.getElementById(ddd).style.display = 'block'} else {document.getElementById(ddd).style.display = 'none'} } </script>
<p class="mod"><a href="javascript: displ('var222')">Профиль</a></p>
<div id="var222" style="display: none;">

<p class="bolden">Ваши данные:</p>
<p class="sbk">Ваше имя:<br><span class='name'><?php echo $arr['names'];?></span></p>
<p class="sbk">Ваш e-mail:<br><span class='name'><?php echo $arr['username'];?></span></p>
</div><a href="javascript: displ('var222')"></a></div>
<form novalidate="novalidate" class="form-signin ajax" method="post" action=
"ajax.php">
   
<input type="hidden" name="act" value="logout">




<input type="submit" class="button" value="Выйти" /></form>
</div><?php else: ?>
 <header>
        <div class="logo">
            <a href="index.html"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:35%; margin:0 auto;padding-top:2%;" id="myTopnav">
                    <a href="http://h90666nq.beget.tech/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/location/index.php">Контакты</a>
                <a href="services.html">Каталог</a>
                
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
        
<h1><style> h1{text-align:center;}
.button { 
  
 text-align:center;
text-decaration:none;
background-color: #000; 
justify-content:center;
margin:35%;	padding: 2px; 
margin-top: -170px;
width:90px;
position:absolute;

}

</style>



<style>table { 
   margin-left:17%;
		width: 70%; 
		border-collapse: collapse; 
		margin-bottom:30px;
			margin-top:15px;
	}
	/* Zebra striping */
	tr:nth-of-type(odd) { 
		background: #eee; 
	}
	th { 
		background: #000; 
		color: white; 
		font-weight: bold; 
		justify-content:center;
		text-align:center;
	}
	td, th { 
		padding: 6px; 
		border: 1px solid #ccc; 
		
	 text-align:center;
	}
	h1{text-align:center;}


	}
	</style>


<font class="button"><a  href="http://h90666nq.beget.tech/index1.php"style="color: white; text-decoration: none" >Войти</a></font>

    <h2 style="text-align: center; margin-top:-20px;"></style>Прейскурант</h2> 
    
    <?php 
    
    require_once 'connection.php'; // подключаем скрипт 
    
    mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
    $handle = mysqli_connect($host, $user, $password, $database) 
    or die("Ошибка " . mysqli_error($handle)); 
    
            $query ="SELECT * FROM prey"; 
            
            $query = "SELECT idprey,
          splav, 
            rub
        
            FROM prey"; 
    $result = $handle->query($query); 
    $numresult=$result->num_rows; 

    echo '<table border=1>'; 
    echo '<tr><th>№ п/п </th>'; 
    echo '<th>Наименование сплава</th>'; 
    echo '<th>Размер займа руб/гр</th>'; 


    
    for ($i=0;$i<$numresult;$i++) 
    { 
    $row=$result->fetch_assoc(); 
    echo '<tr><td>'.$row['idprey']; 
    echo '</td><td>'.$row['splav']; 
    echo '</td><td>'.$row['rub']; 


    echo '</form>'; 
  

    echo '</form>'; 
    } 
    echo '</table>'; 
    
    mysqli_close($handle); 
    ?> 
<p style="text-align: center;">Мы принимаем к оплате карты:<br /> <img src="https://sendflowers.ru/static_files/pay_page/cards_2016.jpg" style="margin: 10px 5px;" /></p>
<p style="color: #ааа; text-align: center;">* Подробную информацию о цене за грамм уточняйте у товароведов-оценщиков.</p></div>
    </body> 
    </html>
    
    
     <?php endif; ?>
    
      <script src="script.js"></script>
    
    <script type="text/javascript" src="jquery-2.0.3.min.js"></script><script type="text/javascript" src="ajax-form.js"></script></body></html>
    
       

  