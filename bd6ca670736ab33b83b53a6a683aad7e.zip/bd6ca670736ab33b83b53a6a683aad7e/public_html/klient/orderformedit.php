<html> 
<head> 
<title>Изменение данных о клиенте
</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
<link rel="stylesheet" href="stylees.css">
</head> 
  <header>
        <div class="logo">
            <img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Вход</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="http://h90666nq.beget.tech/pray/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/katalog/index.php">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav><style>
  .formm{
      text-align:center;
      justify-content:center;
    
    }
    table { 
		width: 50%; 
		border-collapse: collapse;
		margin-left:25%;
		
	}
	/* Zebra striping */
	tr:nth-of-type(odd) { 
		background: #eee; 
	}
	th { 
	 
		background: #000; 
		color: white; 
		font-weight: bold; 
		justify-content:center;
		text-align:center;
	}
	td, th { 
	 
		padding: 6px; 
		border: 1px solid #ccc; 
		
	 
	}
		.knopa{
	    text-align:center;
	    text-decaration:none;
	    background-color: #000; 
color: #fff; 
margin:0 auto;
margin-top: 50px;
width:158px;
    position: relative;

	}
	</style>
<body><div class="formm">
<h1 >Клиенты</h1> 

<h3>Изменение данных</h3> 
<form action="processorderedit.php" method=post> 
<table border=0> 
<tr bgcolor=#cccccc> 
<tr>

<?php 

$idkl= $_REQUEST['idkl']; 
echo '<input type="hidden" name="idkl" value="'.$idkl.'">'; 
require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 
$query = "SELECT idkl, 
        fam, 
        im, 
       otch,
    pasp,
    tel, datar, inn, adres
FROM klient
WHERE idkl=$idkl"; 
$result = $handle->query($query); 
$row=$result->fetch_assoc(); 

echo '<tr ><td>Фамилия<td align=left><input type="text" 
name="fam" size=30 maxlength=30 required value='.$row['fam'].'>'; 



echo '<tr><td>Имя<td align=left><input type="text" name="im"
size=30 maxlength=30 required
value='.$row['im'].'>'; 


echo '<tr><td>Отчество<td align=left><input type="text" 
name="otch" size=30 maxlength=30 required value='.$row['otch'].'>'; 


echo '<tr><td>Паспорт<td align=left><input type="text" 
name="pasp" size=30 maxlength=30 required value='.$row['pasp'].'>'; 

echo '<tr><td>Телефон<td align=left><input type="text" name="tel" size=30 maxlength=30 required
value='.$row['tel'].'>'; 

echo '<tr><td>Дата рождения<td align=left><input type="text" name="datar" size=30 maxlength=30 required
value='.$row['datar'].'>'; 

echo '<tr><td>ИНН<td align=left><input type="text" name="inn" size=30 maxlength=30 required
value='.$row['inn'].'>'; 

echo '<tr><td>Адрес<td align=left><input type="text" name="adres" size=30 maxlength=30 required
value='.$row['adres'].'>'; 
mysqli_close($handle); 
?> 
<tr><td colspan=2 align=center><input type=submit 
value="Изменить"></td></tr> 
</table> <p class="knopa"><a href='index.php'>Список клиентов</a> </div>
</form> 
</body> 
</html>
