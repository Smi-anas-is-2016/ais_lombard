<html> 
<head> 
<title>Внести клиента</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
<link rel="stylesheet" href="stylees.css">
</head> 
   <style>
    .formm{
        position: relative;
left: 50%;
transform: translate(-50%, 0);
    }
</style>
  <header>
        <div class="logo">
            <img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Вход</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="http://h90666nq.beget.tech/pray/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/katalog/index.php">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
     
<body> <div class="formm">
<h4>Внести клиента</h4> 
<p><a href='index.php'>Список клиентов</a> 
<h2>Форма заполнения</h2> 
<form action="processorderadd.php" method=post> 
<table border=0> 
<tr bgcolor=#cccccc> 

<tr> 
<td>Фамилия
<td align=center><input type="text" name="fam" size=60 maxlength=60 required> 
<tr> 
<td>Имя
<td align=left><input type="text" name="im" size=60 maxlength=60 required>

<tr>
<td>Отчество
<td align=left><input type="text" name="otch" size=60 maxlength=60 required>
<tr>
<td>Паспортные данные
<td align=left><input type="text" name="pasp" size=60 maxlength=60 required>
<tr>
<td>Телефон
<td align=left><input type="text" name="tel" size=60 maxlength=60 required>
<td>Дата Рождения
<td align=left><input type="text" name="datar" size=60 maxlength=60 required>
<td>ИНН
<td align=left><input type="text" name="adres" size=60 maxlength=60 required>

<tr> 
<td colspan=2 align=center><input type=submit value="Внести клиента"></td> 
</table> </div>
</form> 
</body> 
</html>