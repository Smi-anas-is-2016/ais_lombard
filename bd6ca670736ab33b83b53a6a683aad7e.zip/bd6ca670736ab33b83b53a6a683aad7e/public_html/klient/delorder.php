<html> 
<head> 
<title>Удаление клиента
</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
<link rel="stylesheet" href="stylees.css">
</head> 
<body> 
  <header>
        <div class="logo">
            <img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Вход</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="http://h90666nq.beget.tech/pray/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/katalog/index.php">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
<h1>Клиенты</h1> 
<h2>Удаление клиента</h2> 
<?php 


$query ="SELECT * FROM klient"; 


$idkl= $_REQUEST['idkl']; 

require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 

$query = "DELETE FROM klient WHERE idkl=$idkl"; 
$result = $handle->query($query); 
if ($result) echo "Данные удалены"; 
if (!$result) echo "Ошибка удаления данных"; 
echo "<p><a href='index.php'>Cписок клиентов</a>"; 
mysqli_close($handle); 
?> 
</body> 
</html>