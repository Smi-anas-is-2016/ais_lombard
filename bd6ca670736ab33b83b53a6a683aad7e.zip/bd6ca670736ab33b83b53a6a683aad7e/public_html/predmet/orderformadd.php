<html> 
<head> 
<title>Внести клиента</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
</head> 
<body> 
<h1>Внести клиента</h1> 
<p><a href='index.php'>Список клиентов</a> 
<h2>Форма заполнения</h2> 
<form action="processorderadd.php" method=post> <link rel="shortcut icon" href="https://img2.pngindir.com/20180330/ggw/kisspng-light-yagami-letter-alphabet-clip-art-l-5abdf8c81fe3f9.0592132715223994321306.jpg" type="image/x-icon"> 
<table border=0> 
<tr bgcolor=#cccccc> 


<tr> 
<td>Предмет
<td align=left><input type="text" name="pred" size=60 maxlength=60 required> 
<tr> 
<td>Вес
<td align=left><input type="text" name="ves" size=60 maxlength=60 required>

<tr>
<td>Наличие камней
<td align=left><input type="text" name="kamn" size=60 maxlength=60 required>
<tr>
<td>Металл
<td align=left><input type="text" name="metall" size=60 maxlength=60 required>
<tr>
<td>Проба
<td align=left><input type="text" name="proba" size=60 maxlength=60 required>
    <tdКлиент
            <td>
                   <?php
                 require_once 'connection.php'; // подключаем скрипт
                 $handle = mysql_connect($host, $user, $password, $database);
                 $dbcon=mysql_select_db($database);
                 $query="SELECT * FROM klient";
                 $result=mysql_query($query);
                 
                 echo "<select name='fio'>";
                 while ($line = mysql_fetch_array($result, MYSQL_ASSOC))
                 {
                    echo '<option selected value="'.$line['fio'].'" >'.$line['fio'];
                 }
                 echo "</select>\n";
               mysqli_close($handle);
            ?>  


<tr> 
<td colspan=2 align=center><input type=submit value="Внести предмет"></td> 
</table> 
</form> 
</body> 
</html>