


<?php
if (!empty($_COOKIE['sid'])) {session_id($_COOKIE['sid']);}
session_start();
require_once 'classes/Auth.class.php';
require_once 'stayt.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>Главная страница</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="stylees.css">
 <link rel="shortcut icon" href="https://img2.pngindir.com/20180330/ggw/kisspng-light-yagami-letter-alphabet-clip-art-l-5abdf8c81fe3f9.0592132715223994321306.jpg" type="image/x-icon">
</head>
<style>table { 
		width: 100%; 
		border-collapse: collapse; 
	}
	/* Zebra striping */
	tr:nth-of-type(odd) { 
		background: #eee; 
	}
	th { 
		background: #000; 
		color: white; 
		font-weight: bold; 
		justify-content:center;
		text-align:center;
	}
	td, th { 
		padding: 6px; 
		border: 1px solid #ccc; 
		
	 
	}
	h1{text-align:center;}
	.knopa{
	    text-align:center;
	    text-decaration:none;
	    background-color: #000; 
justify-content:center;
margin:0 auto;	padding: 8px; 
margin-top: 50px;
width:150px;

    

	}</style>
<body>

<?php if (Auth\User::isAuthorized()): ?>
   <header>
        <div class="logo">
            <img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Вход</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="http://h90666nq.beget.tech/pray/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/katalog/index.php">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
<div class="omus">

<script type="text/javascript"> function displ(ddd) { if (document.getElementById(ddd).style.display == 'none') {document.getElementById(ddd).style.display = 'block'} else {document.getElementById(ddd).style.display = 'none'} } </script>

<div id="var222" style="display: none;">


</div><a href="javascript: displ('var222')"></a></div>
<form novalidate="novalidate" class="form-signin ajax" method="post" action=
"ajax.php">
    
         <nav>
             <h1>Предметы залога</h1> 

<!--<p><a href='orderformadd.php'>Внести клиента в базу</a> -->

            <?php 
require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 

        $query ="SELECT * FROM predmet"; 
        
        $query = "SELECT idpred,
        pred, 
        ves, 
       kamn,
    	metall,
    proba
        FROM predmet"; 
$result = $handle->query($query); 
$numresult=$result->num_rows; 
echo '<p>Количество записей - '.$numresult; 
echo '<table border=1>'; 

echo '<tr><th>Предмет</th>'; 
echo '<th>Вес</th>'; 
echo '<th>Наличие камней</th>'; 
echo '<th>Металл</th>'; 
echo '<th>Проба</th>'; 

echo '<th></th>'; 
 echo '<th>Изменить</th>'; 

for ($i=0;$i<$numresult;$i++) 
{ 
$row=$result->fetch_assoc(); 

echo '<tr><td>'.$row['pred']; 
echo '</td><td>'.$row['ves']; 
echo '</td><td>'.$row['kamn']; 
echo '</td><td>'.$row['metall']; 
echo '</td><td>'.$row['proba']; 
 
echo '</td><td>'; 

echo '</form>'; 
echo '</td><td>'; 
echo '<form action="orderformedit.php" method="post">'; 
echo '<input type="hidden" name="idpred" value="'.$row['idpred'].'">'; 
echo '<input type="submit" value="Изменить">'; 
echo '</form>'; 
} 
echo '</table>'; 

mysqli_close($handle); 
?>   <p class="knopa"><a href='../index.php'style="color: white; text-decoration: none">На главную</a> </p>

<?php else: ?>
        <div class="logo">
            <a href="index.html"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Главная</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="about.html">Локация</a>
                <a href="services.html">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>       
 
        
<h1><style> h1{text-align:center;padding-top:50px;}
.button { 
 text-align:center;
	    text-decaration:none;
	    background-color: #000; 
justify-content:center;
margin:0 auto;	padding: 8px; 
margin-top: 50px;
width:150px;


}
</style>


<div id="wrapper">

	


<font> <h1>	Пожалуйста, войдите в систему! </h1></font><BR>

<font class="button"><a  href="http://h90666nq.beget.tech/index.php"style="color: white; text-decoration: none" >Войти</a></font>
</div>


</main>
    
 <?php endif; ?> 



        

<script type="text/javascript" src="jquery-2.0.3.min.js"></script><script type="text/javascript" src="ajax-form.js"></script></body></html>