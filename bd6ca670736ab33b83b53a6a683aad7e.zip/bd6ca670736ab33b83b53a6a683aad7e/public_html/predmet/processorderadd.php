<html> 
<head> 
<title>Внести клиента
</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
 <link rel="shortcut icon" href="https://img2.pngindir.com/20180330/ggw/kisspng-light-yagami-letter-alphabet-clip-art-l-5abdf8c81fe3f9.0592132715223994321306.jpg" type="image/x-icon">
</head> 
<body> 
<h1>Список клиентов</h1> 
<h2>Результаты оформления</h2> 

<?php 

$pred = $_REQUEST['pred']; 
$ves = $_REQUEST['ves']; 
$kamn = $_REQUEST['kamn']; 
$metall= $_REQUEST['metall']; 
$proba= $_REQUEST['proba']; 

require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 
$query = "INSERT INTO predmet (pred,ves,kamn,metall,proba) VALUES ('$pred', '$ves', '$kamn', '$metall','$proba')"; 
$result = $handle->query($query); 
if ($result) echo "Данные сохранены"; 
if (!$result) echo "Ошибка сохранения данных"; 
echo "<p><a href='index.php'>Список клиентов</a>"; 

mysqli_close($handle); 
?> 
</body> 
</html>