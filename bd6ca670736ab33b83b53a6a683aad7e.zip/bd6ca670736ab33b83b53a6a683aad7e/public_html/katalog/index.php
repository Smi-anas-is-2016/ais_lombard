
<?php
if (!empty($_COOKIE['sid'])) {session_id($_COOKIE['sid']);}
session_start();
require_once 'classes/Auth.class.php';
require_once 'stayt.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>Главная страница</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="stylees.css">
<link rel="stylesheet" href="st.css">

<link rel="shortcut icon" href="https://img2.pngindir.com/20180330/ggw/kisspng-light-yagami-letter-alphabet-clip-art-l-5abdf8c81fe3f9.0592132715223994321306.jpg" type="image/x-icon">
</head>

<body>

<?php if (Auth\User::isAuthorized()): ?>
    <header>
        <div class="logo">
            <img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Вход</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="http://h90666nq.beget.tech/pray/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/katalog/index.php">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
<style>
    * {box-sizing: border-box;}
.product-item {margin-left:15%;
  width: 300px;
  text-align: center;

  border-bottom: 2px solid #F5F5F5;
  background: white;
  font-family: "Open Sans";
  transition: .3s ease-in;
  
}
.product-item:hover {border-bottom: 2px solid #fc5a5a;}
.product-item img {
  display: block;
  width: 100%;
}
.product-list {
  background: #fafafa;
  padding: 15px 0;
}
.product-list h3 {
  font-size: 18px;
  font-weight: 400;
  color: #444444;
  margin: 0 0 10px 0;
}
.price {
  font-size: 20px;
  color: #fc5a5a;
  display: block;
  margin-bottom: 12px;
}
.button {
  text-decoration: none;
  display: inline-block;
  padding: 0 12px;
  background: #cccccc;
  color: white;
  text-transform: uppercase;
  font-size: 12px;
  line-height: 28px;
  transition: .3s ease-in;
}
.product-item:hover .button {background: #fc5a5a; }
.pppp{
    margin-top:-36%;
    padding-left:30%;
}
.ppp{
    margin-top:-37.4%;
    padding-left:60%;
}
</style>
</head>
<main>
  <div class="product-item">
  <img src="https://lombardunion.com/upload/resize_cache/iblock/8fa/380_500_1/8fa531aef5228296bae4ea038bc758b6.png">
  <div class="product-list">
    <h2>Кольцо</h2>
    <h3>Проба: 583<br>
Металл: золото<br>
Общий вес: 6.47<br>
Описание: 7 брилл обр</h3>
      <span class="price">18 900 ₽ </span>
      </div>
    
  </div>
</div>


<div class="pppp">
  <div class="product-item">
  <img src="https://lombardunion.com/upload/resize_cache/iblock/d0d/380_500_1/d0d35aaf0a7517e700a02018470e34dc.png">
  <div class="product-list">
    <h2>Кольцо</h2>
    <h3>Проба: 585<br>
Металл: золото<br>
Общий вес: 2.49<br>
Описание:2 брилл обр</h3>
      <span class="price">14 900 ₽ </span>
      </div>
    
  </div>
</div></div>

<div class="ppp">
  <div class="product-item">
  <img src="https://lombardunion.com/upload/resize_cache/iblock/523/380_500_1/5237a435f945d72bef2d996bcc9be512.png">
  <div class="product-list">
    <h2>Кольцо</h2>
    <h3>Проба: 585<br>
Металл: золото<br>
Общий вес: 3.96<br>
Описание:2 корич кам</h3>
      <span class="price">7 900 ₽ </span>
      </div>
    
  </div>
</div></div>

    
    
    
</main>


<?php else: ?>
        <div class="logo">
            <a href="index.html"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Главная</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="about.html">Локация</a>
                <a href="services.html">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>       
 
        
<h1><style> h1{text-align:center;padding-top:50px;}
.button { 
 text-align:center;
text-decaration:none;
background-color: #000; 
justify-content:center;
margin:0 auto;	padding: 8px; 
margin-top: 50px;
width:150px;


}
</style>


<div id="wrapper">

	


<font> <h1>	Пожалуйста, войдите в систему! </h1></font><BR>

<font class="button"><a  href="http://h90666nq.beget.tech/index.php"style="color: white; text-decoration: none" >Войти</a></font>
</div>


</main>
    
 <?php endif; ?> 



        

</body></html>