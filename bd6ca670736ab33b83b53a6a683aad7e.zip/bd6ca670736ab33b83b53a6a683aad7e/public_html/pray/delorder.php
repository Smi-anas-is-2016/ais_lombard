
<!DOCTYPE html>
<html lang="ru">
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="stylees.css">
<link rel="stylesheet" href="st.css">
</head> 
<body> 

</body> 
</html>



 <header>
        <div class="logo">
            <a href="index.html"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Главная</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="about.html">Прайс</a>
                <a href="services.html">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>

</head>






<?php
if (!empty($_COOKIE['sid'])) {session_id($_COOKIE['sid']);}
session_start();
require_once 'classes/Auth.class.php';
require_once 'stayt.php';
?>


<?php if (Auth\User::isAuthorized()): ?>
<div class="omus">

<script type="text/javascript"> function displ(ddd) { if (document.getElementById(ddd).style.display == 'none') {document.getElementById(ddd).style.display = 'block'} else {document.getElementById(ddd).style.display = 'none'} } </script>

<div id="var222" style="display: none;">


</div><a href="javascript: displ('var222')"></a></div>
<form novalidate="novalidate" class="form-signin ajax" method="post" action=
"ajax.php">
<h2>Удаление клиента</h2> 
            <?php 
$query ="SELECT * FROM prey"; 


$idprey= $_REQUEST['idprey']; 

require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 

$query = "DELETE FROM prey WHERE idprey=$idprey"; 
$result = $handle->query($query); 
if ($result) echo "Данные удалены"; 
if (!$result) echo "Ошибка удаления данных"; 
echo "<p><a href='index.php'>Cписок клиентов</a>"; 
mysqli_close($handle); 
?> 



<?php else: ?>





<script type="text/javascript" src="jquery-2.0.3.min.js"></script><script type="text/javascript" src="ajax-form.js"></script>











