<html> 
<head> 
<title>Внести 
</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
<link rel="stylesheet" href="stylees.css">
</head> 
  <header>
        <div class="logo">
            <img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Вход</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="http://h90666nq.beget.tech/pray/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/katalog/index.php">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
<body> 
<h1>Список клиентов</h1> 
<h2>Результаты оформления</h2> 

<?php 

$splav = $_REQUEST['splav']; 
$rub = $_REQUEST['rub']; 


require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 
$query = "INSERT INTO prey (splav,rub) VALUES ('$splav', '$rub')"; 
$result = $handle->query($query); 
if ($result) echo "Данные сохранены"; 
if (!$result) echo "Ошибка сохранения данных"; 
echo "<p><a href='index.php'>Список клиентов</a>"; 

mysqli_close($handle); 
?> 
</body> 
</html>