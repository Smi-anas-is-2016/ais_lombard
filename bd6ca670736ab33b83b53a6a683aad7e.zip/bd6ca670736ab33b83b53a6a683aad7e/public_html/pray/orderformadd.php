<html> 
<head> 
<title>Внести позицию</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
<link rel="stylesheet" href="stylees.css">
   <style>
    .formm{
        position: relative;
        padding-left:29%;


    }
</style>
   <header><style>table { 
		width: 100%; 
		border-collapse: collapse; 
		margin-left:-10%;
	}
	/* Zebra striping */
	tr:nth-of-type(odd) { 
		background: #eee; 
	}
	th { 
		background: #000; 
		color: white; 
		font-weight: bold; 
		justify-content:center;
		text-align:center;
	}
	td, th { 
		padding: 6px; 
		border: 1px solid #ccc; 
		
	 
	}
	h2{text-align:center;
	    margin-bottom:3%;
	    margin-left:-45%;
	}
	.knopa{
	    text-align:center;
	    text-decaration:none;
	    background-color: #000; 
        justify-content:right;
        margin:0 auto;	padding: 16px; 
        margin-top: 50px;
        width:150px;
       margin-left:-45%;
	}

	</style>
        <div class="logo">
            <img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Вход</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="http://h90666nq.beget.tech/pray/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/katalog/index.php">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
     
<body> <div class="formm">


<form action="processorderadd.php" method=post> 
<table border=0> 
<tr bgcolor=#cccccc> 
<body> 
<h2>Внести позицию</h2> 


<form action="processorderadd.php" method=post> 
<table border=0> 
<tr bgcolor=#cccccc> 

<tr> 
<td>Наименование сплава
<td align=left><input type="text" name="splav" size=55 maxlength=60 required> 
<tr> 
<td>Размер займа руб/гр
<td align=left><input type="text" name="rub" size=15 maxlength=60 required>
</table> 

<p colspan=2 align=center><input type=submit class=knopa style="color: white; text-decoration: none" value="Внести">

</form> 
</body> 
</html>