<html> 
<head> 
<title>Изменение данных 
</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
<link rel="stylesheet" href="css/main.css?v=3.4.2">
 <link rel="shortcut icon" href="https://img2.pngindir.com/20180330/ggw/kisspng-light-yagami-letter-alphabet-clip-art-l-5abdf8c81fe3f9.0592132715223994321306.jpg" type="image/x-icon">
 <link rel="stylesheet" type="text/css" href="stylees.css?v=3.4.2">
</head> <header>
        <div class="logo">
            <img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>

<style>
 .formm{

        padding-left:35%;

}
	h2{text-align:center;
	    margin-bottom:3%;
	    margin-left:-1%;
	}
	.knopa{
	    text-align:center;
	    text-decaration:none;
	    background-color: #000; 
        justify-content:right;
        margin:0 auto;	padding: 16px; 
        margin-top: 50px;
        width:150px;
       margin-left:6%;
	}

    </style>
    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Вход</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="http://h90666nq.beget.tech/pray/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/katalog/index.php">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
<body> 


<h2>Изменение данных</h2> <div class=formm>
<form action="processorderedit.php" method=post> 
<table border=0> 
<tr bgcolor=#cccccc> 
<tr>

<?php 

$idprey= $_REQUEST['idprey']; 
echo '<input type="hidden" name="idprey" value="'.$idprey.'">'; 
require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 
$query = "SELECT idprey, 
     splav, 
       rub
FROM prey
WHERE idprey=$idprey"; 
$result = $handle->query($query); 
$row=$result->fetch_assoc(); 

echo '<tr><td>Сплав<td align=left><input type="text" 
name="splav" size=30 maxlength=30 required value='.$row['splav'].'>'; 



echo '<tr><td>Размер займа руб/гр<td align=left><input type="text" name="rub"
size=30 maxlength=30 required
value='.$row['rub'].'>'; 





mysqli_close($handle); 
?> </div>
<tr><td colspan=2 align=center><input type=submit class=knopa  style="color: white; text-decoration: none"
value="Изменить"></td></tr> 
</table> 
</form> 
</body> 
</html>
