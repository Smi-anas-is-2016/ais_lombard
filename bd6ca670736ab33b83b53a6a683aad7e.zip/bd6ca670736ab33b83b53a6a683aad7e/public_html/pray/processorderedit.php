<html> 
<head> 
<title>Изменение
</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
</head> 
<body> 

<h2>Результаты изменения</h2> 
<?php 



//$query ="SELECT * FROM stud"; 

$idprey=$_REQUEST['idprey'];
$splav = $_REQUEST['splav']; 
$rub = $_REQUEST['rub']; 


require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 

$query = "UPDATE prey SET 


splav='$splav', 
rub='$rub'
WHERE idprey='$idprey'"; 
$result = $handle->query($query); 
if ($result) echo "Данные сохранены"; 
if (!$result) echo "Ошибка сохранения данных"; 
echo "<p><a href='index.php'>список блюд</a>"; 

mysqli_close($handle); 
?> 
</body> 
</html>