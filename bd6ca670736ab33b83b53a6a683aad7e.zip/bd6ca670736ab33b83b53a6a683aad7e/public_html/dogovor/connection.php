<?php
$host = 'localhost'; // адрес сервера 
$database = 'h90666nq_q'; // имя базы данных
$user = 'h90666nq_q'; // имя пользователя
$password = 'qwerty'; // пароль
?>