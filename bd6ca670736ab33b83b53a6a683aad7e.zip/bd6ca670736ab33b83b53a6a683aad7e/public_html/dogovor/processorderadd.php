<html> 
<head> 
<title>Внести клиента
</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
</head> 
<body> 
<h1>Список клиентов</h1> 
<h2>Результаты оформления</h2> 

<?php 
$fam = $_REQUEST['fam']; 
$im = $_REQUEST['im']; 
$otch = $_REQUEST['otch']; 
$pasp= $_REQUEST['pasp']; 
$tel= $_REQUEST['tel']; 


$pred = $_REQUEST['pred']; 
$ves = $_REQUEST['ves']; 
$kamn = $_REQUEST['kamn']; 
$metall= $_REQUEST['metall']; 
$proba= $_REQUEST['proba'];


$dataz = $_REQUEST['dataz']; 
$sumzal = $_REQUEST['sumzal']; 
$sumzaima = $_REQUEST['sumzaima']; 
$srok= $_REQUEST['srok']; 



require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 
$query = "INSERT INTO klient (fam,im,otch,pasp,tel) VALUES ('$fam', '$im', '$otch', '$pasp','$tel')"; 
$result = $handle->query($query); 

require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 
$query = "INSERT INTO predmet (pred,ves,kamn,metall,proba) VALUES ('$pred', '$ves', '$kamn', '$metall','$proba')"; 
$result = $handle->query($query); 

require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 
$query = "INSERT INTO dogovor (dataz,sumzal,sumzaima,srok) VALUES ('$dataz', '$sumzal', '$sumzaima', '$srok')"; 
$result = $handle->query($query); 


if ($result) echo "Данные сохранены"; 
if (!$result) echo "Ошибка сохранения данных"; 
echo "<p><a href='index.php'>Список клиентов</a>"; 

mysqli_close($handle); 
?> 
</body> 
</html>