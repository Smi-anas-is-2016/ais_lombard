<html> 
<head> 
<title>Внести клиента</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
<link rel="stylesheet" href="stylees.css">
</head> 
   <style>
    .formm{
        position: relative;
        padding-left:29%;


    }
</style>
   <header>
        <div class="logo">
            <img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Вход</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="http://h90666nq.beget.tech/pray/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/katalog/index.php">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
     
<body> <div class="formm">


<form action="processorderadd.php" method=post> 
<table border=0> 
<tr bgcolor=#cccccc> 

<td>Фамилия
<td align=left><input type="text" name="fam" size=60 maxlength=60 required>
   <tr> 

<td>Имя
<td align=left><input type="text" name="im" size=60 maxlength=60 required>
   <tr> 
<td>Отчетсво
<td align=left><input type="text" name="otch" size=60 maxlength=60 required>
   <tr> 

<td>Паспорт
<td align=left><input type="text" name="pasp" size=60 maxlength=60 required>
   <tr> 
<td>Телефон
<td align=left><input type="text" name="tel" size=60 maxlength=60 required>
   <tr> 
<tr> 
<td>Предмет
<td align=left><input type="text" name="pred" size=60 maxlength=60 required> 
<tr> 
<td>Вес
<td align=left><input type="text" name="ves" size=60 maxlength=60 required>

<tr>
<td>Наличие камней
<td align=left><input type="text" name="kamn" size=60 maxlength=60 required>
<tr>
<td>Металл
<td align=left><input type="text" name="metall" size=60 maxlength=60 required>
<tr>
<td>Проба
<td align=left><input type="text" name="proba" size=60 maxlength=60 required>
<tr>
<td align=left for="date"> <td> Дата сдачи в залог
                <input type="date" id="dataz" name="dataz">
<tr>
<td>Сумма залога
<td align=left><input type="text" name="sumzal" size=60 maxlength=60 required>
<tr>
<td>Сумма займа
<td align=left><input type="text" name="sumzaima" size=60 maxlength=60 required>
  <tr>
<td>Срок
<td align=left><input type="text" name="srok" size=60 maxlength=60 required>
  


<td colspan=2 align=center><input type=submit value="Внести"></td> 
</table> 
</form> 
</body> 
</html>