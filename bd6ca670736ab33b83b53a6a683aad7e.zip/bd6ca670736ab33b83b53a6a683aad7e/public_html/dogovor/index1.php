<?php
if (!empty($_COOKIE['sid'])) {session_id($_COOKIE['sid']);}
session_start();
require_once 'classes/Auth.class.php';
require_once 'stayt.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>Главная страница</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css?v=3.4.2">
 <link rel="shortcut icon" href="https://img2.pngindir.com/20180330/ggw/kisspng-light-yagami-letter-alphabet-clip-art-l-5abdf8c81fe3f9.0592132715223994321306.jpg" type="image/x-icon">
 <link rel="stylesheet" type="text/css" href="stylees.css?v=3.4.2">
</head>

<body>
<style>table { 
		width: 100%; 
		border-collapse: collapse; 
		margin-left:-10%;
	}
	/* Zebra striping */
	tr:nth-of-type(odd) { 
		background: #eee; 
	}
	th { 
		background: #000; 
		color: white; 
		font-weight: bold; 
		justify-content:center;
		text-align:center;
	}
	td, th { 
		padding: 6px; 
		border: 1px solid #ccc; 
		
	 
	}
	h1{text-align:center;}
	.knopa{
	    text-align:center;
	    text-decaration:none;
	    background-color: #000; 
        justify-content:right;
        margin:0 auto;	padding: 16px; 
        margin-top: 50px;
        width:150px;
        margin-top:-50px;
        margin-left:79%;
	}
		.knopa1{
	    text-align:center;
	    text-decaration:none;
	    background-color: #000; 
        justify-content:center;
        margin:2 auto;	padding: 8px; 
        margin-top: 50px;
        width:150px;
	}
	</style>
<body>

<?php if (Auth\User::isAuthorized()): ?>

 <header>
        <div class="logo">
            <a href="index.html"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>


 <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Главная</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="about.html">Локация</a>
                <a href="services.html">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>

<div class="omus">

<script type="text/javascript"> function displ(ddd) { if (document.getElementById(ddd).style.display == 'none') {document.getElementById(ddd).style.display = 'block'} else {document.getElementById(ddd).style.display = 'none'} } </script>

<div id="var222" style="display: none;">


</div><a href="javascript: displ('var222')"></a></div>
<form novalidate="novalidate" class="form-signin ajax" method="post" action=
"ajax.php">
    
         <nav>
             <h1>Договор</h1> 



            <?php 

require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle)); 
//$query="SELECT * FROM predmet, klient WHERE predmet.idpred > klient.idkl";
    $query1="SELECT * FROM klient";
    $query2="SELECT * FROM predmet";
  
  
$query =$query1; 
$result = $handle->query($query); 
$numresult=$result->num_rows; 

$query =$query2; 
$result2 = $handle->query($query); 
$numresult2=$result2->num_rows; 

echo '<p>Количество заключенных договоров - '.$numresult;

 for ($i=0;$i<$numresult;$i++) 
{ 
    $row=$result->fetch_assoc(); 
$fam=$row['fam']; 
  $im=$row['im']; 
    $im=$row['otch']; 
    $im=$row['pasp']; 
  echo'<br>';
    
     $row=$result2->fetch_assoc(); 
   
    echo '</td><td>'.$row['pred']; 
    echo '</td><td>'.$row['ves']; 
    echo '</td><td>'.$row['kamn']; 
    echo '</td><td>'.$row['metall']; 
    echo '</td><td>'.$row['proba'];


}









echo '</table>'; 

?> <p class="knopa1"><a href='orderformadd.php'style="color: white; text-decoration: none">Внести договор в базу</a> </p>

 <p class="knopa">
     
<a href='../index.php'style="color: white; text-decoration: none">На главную</a> </p>

</form></div><?php else: ?>


        <div class="logo">
            <a href="index.html"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="http://h90666nq.beget.tech/index.php">Главная</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="http://h90666nq.beget.tech/predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="about.html">Локация</a>
                <a href="services.html">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>       
 
        
<h1><style> h1{text-align:center;padding-top:50px;}
.button { 
 text-align:center;
	    text-decaration:none;
	    background-color: #000; 
justify-content:center;
margin:0 auto;	padding: 8px; 
margin-top: 50px;
width:150px;


}
</style>


<div id="wrapper">

	


<font> <h1>	Пожалуйста, войдите в систему! </h1></font><BR>

<font class="button"><a  href="http://h90666nq.beget.tech/index.php"style="color: white; text-decoration: none" >Войти</a></font>
</div>


</main>
    
 <?php endif; ?> 



        

<script type="text/javascript" src="jquery-2.0.3.min.js"></script><script type="text/javascript" src="ajax-form.js"></script></body></html>