<html> 
<head> 
<title>Изменение данных о клиенте
</title> 
<meta name='viewport' content='width=device-width, initial-scale=1.0' 
charset='utf-8'> 
</head> 
<body> 
<h1>Клиенты</h1> 
<p><a href='index.php'>Список клиентов</a> 
<h2>Изменение данных</h2> 
<form action="processorderedit.php" method=post> 
<table border=0> 
<tr bgcolor=#cccccc> 
<tr>



  <td>Клиент
            <td>
                <?php
                     require_once 'connection.php'; // подключаем скрипт
                     $handle = mysql_connect($host, $user, $password, $database);
                     $dbcon=mysql_select_db($database);
                     $query="SELECT * FROM klient";
                     $result=mysql_query($query);
                     
                     echo "<select name='fam'>";
                     while ($line = mysql_fetch_array($result, MYSQL_ASSOC))
                     {
                        echo '<option selected value="'.$line['fam'].'" >'.$line['fam'];
                     }
                     echo "</select>\n";
                 mysql_close($handle);
 ?>
 <?php
$idpred= $_REQUEST['idpred']; 
echo '<input type="hidden" name="idpred" value="'.$idpred.'">'; 
require_once 'connection.php'; // подключаем скрипт 
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
$handle = mysqli_connect($host, $user, $password, $database) 
or die("Ошибка " . mysqli_error($handle));
   
$query ="SELECT idpred,
        pred, 
        ves, 
       kamn,
    	metall,
    proba
FROM predmet
WHERE idpred=$idpred"; 
$result = $handle->query($query); 
$row=$result->fetch_assoc(); 

echo '<tr><td>Предмет<td align=left><input type="text" 
name="pred" size=30 maxlength=30 required value='.$row['pred'].'>'; 



echo '<tr><td>Вес<td align=left><input type="text" name="ves"
size=30 maxlength=30 required
value='.$row['ves'].'>'; 


echo '<tr><td>Наличие камней<td align=left><input type="text" 
name="kamn" size=30 maxlength=30 required value='.$row['kamn'].'>'; 


echo '<tr><td>Металл<td align=left><input type="text" 
name="metall" size=30 maxlength=30 required value='.$row['metall'].'>'; 

echo '<tr><td>Проба<td align=left><input type="text" name="proba" size=30 maxlength=30 required
value='.$row['proba'].'>'; 









mysqli_close($handle); 
?> 
<tr><td colspan=2 align=center><input type=submit 
value="Изменить"></td></tr> 
</table> 
</form> 
</body> 
</html>
