<?php
if (!empty($_COOKIE['sid'])) {session_id($_COOKIE['sid']);}
session_start();
require_once 'classes/Auth.class.php';
require_once 'stayt.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    	
<meta name="robots" content="noindex,follow" />
<meta charset="utf-8"><meta name="yandex-verification" content="d0cd20a4138667e1" />
<title>Главная страница</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css?v=3.4.2">
 <link rel="shortcut icon" href="https://img2.pngindir.com/20180330/ggw/kisspng-light-yagami-letter-alphabet-clip-art-l-5abdf8c81fe3f9.0592132715223994321306.jpg" type="image/x-icon">
 <link rel="stylesheet" type="text/css" href="stylees.css?v=3.4.2">
  <link rel="stylesheet" type="text/css" href="sty.css?v=3.4.2">
</head>


 <header>
        <div class="logo">
            <a href="index.html"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:35%; margin:0 auto;padding-top:2%;" id="myTopnav">
                    <a href="http://h90666nq.beget.tech/index.php">Прайс</a>
                <a href="http://h90666nq.beget.tech/location/index.php">Контакты</a>
                <a href="services.html">Каталог</a>
                
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
        
<h1><style> h1{text-align:center;}
.button { 
  
 text-align:center;
text-decaration:none;
background-color: #000; 
justify-content:center;
margin:35%;	padding: 2px; 
margin-top: -170px;
width:90px;
position:absolute;

}
#block-contact{
    margin-top:-90px;
}
</style>




 <div id='block-contact' class='block block-color'>
                    <div class='wrap'>   <div id='block-map' class='block'>
                        <h2 class='tac'>Контакты</h2>
                        <p class='tac p'>Компания «Ломбард» — надежный помощник в затруднительном материальном положении. 
                        
                        Наша задача — предоставить клиенту необходимую сумму в минимальные сроки.
                        Доверьтесь опыту «Ломбарду» и оцените преимущества надёжного сотрудничества!</p>
                        <ul class='list list-4'>
                            <li class='item cell'>
                                <img class='img' src='/pray/img/door.png' />
                                <div class='phone tc1'>Адрес</div>
                                <div class='city'>г. Кострома, ул. Советская, 134/10</div>
                            </li>
                            <li class='item cell'>
                                <img class='img' src='/pray/img/clipboard.png' />
                                <div class='phone tc1'>Телефон</div>
                                <div class='city'>8 (4942) 385-468</div>
                            </li>
                            <li class='item cell'>
                                <img class='img' src='/pray/img/email.png' />
                                <div class='phone tc1'>Эл. почта</div>
                                <div class='city'>kostroma@lovbard.ru</div>
                            </li>
                            <li class='item cell last'>
                                <img class='img' src='/pray/img/crossroads.png' />
                                <div class='phone tc1'>Время работы</div>
                                <div class='city'>Вт - Сб с 10:00 до 18:00</div>
                                <div class='city'><span style="color: red;">⬤</span><span style="color: black;">⬤⬤⬤⬤⬤</span><span style="color: red;">⬤</span></div>                            
                            </li>
                        </ul>
                    </div>
                </div>

                <div id='block-social' class='block block-why'>
                    <div class='wrap'>
                        <h2 class='tac'>Ломбард в социальных сетях</h2>
                        <p class='tac p'></p>
                        <ul class='list list-1'>
                            <li class='item cell'>
                                <script type="text/javascript" src="//vk.com/js/api/openapi.js?127"></script>
                                <!-- VK Widget -->
                                <div id="vk_groups1" style='margin: auto;'></div>
                                <script type="text/javascript">
                                    VK.Widgets.Group("vk_groups1", {
                                        redesign: 1,
                                        mode: 3,
                                        width: "220",
                                        height: "400",
                                        color1: 'FFFFFF',
                                        color2: '000000',
                                        color3: '31849B',
                                        wide: 0
                                    }, 170253365);
                                </script>
                            </li>
                        </ul>
                    </div>
                </div>
                <div id='block-map' class='block'>
                    <h2 class='tac'>Ломбард на карте</h2>
                    <div id='map'>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d17033.592450598935!2d40.94115839284901!3d57.74704398505108!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46ad4fd142ce7b0f%3A0x546dea1c06e83e6d!2z0JvQvtC80LHQsNGA0LQ!5e0!3m2!1sru!2sru!4v1578598150286!5m2!1sru!2sru" width="100%" height="100%" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                    </div>
                </div>
            </div>
            
             <footer>
<div class="footer-container"><div class="foot">
<style>
    .foot{background-color:black;
        margin-top:-35px;
        width:100%;
        height:10%;
       
        
    }
    h7{
       color:white;
        font-size: 16px;

    font-weight: normal;

    }
    
    </style>
<h7>Курсовая работа. Разработка информационной системы "Ломбард", студентка группы 4-1ИС, Смирнова А.А. ОГБПОУ техникум им. Ф.В. Чижова. 2019</h7>
    </footer>
            </div>
    </center>
        <script src="script.js"></script>
    
    <script type="text/javascript" src="jquery-2.0.3.min.js"></script><script type="text/javascript" src="ajax-form.js"></script></body></html>
    
       

  