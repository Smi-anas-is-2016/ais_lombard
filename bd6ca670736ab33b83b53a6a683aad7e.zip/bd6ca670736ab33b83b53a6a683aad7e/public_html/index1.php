<?php
if (!empty($_COOKIE['sid'])) {session_id($_COOKIE['sid']);}
session_start();
require_once 'classes/Auth.class.php';
require_once 'stayt.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8"><meta name="yandex-verification" content="d0cd20a4138667e1" />
<title>Главная страница</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css?v=3.4.2">
 <link rel="shortcut icon" href="https://img2.pngindir.com/20180330/ggw/kisspng-light-yagami-letter-alphabet-clip-art-l-5abdf8c81fe3f9.0592132715223994321306.jpg" type="image/x-icon">
 <link rel="stylesheet" type="text/css" href="stylees.css?v=3.4.2">
</head>

<body>

  
<?php if (Auth\User::isAuthorized()): ?>

 <header>
        <div class="logo">
            <a href="index1.php"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="index1.php">Вход</a>
                <a href="klient/index.php">Клиенты</a>
                <a href="predmet/index.php">Предметы</a>
                <a href="dogovor/index.php">Договора</a>
                <a href="pray/index.php">Прайс</a>
                <a href="katalog/index.php">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>

<div class="omus">
<?php echo "<p class='privet'>Здравствуй, <span>".$arr['names']."</span>!</p>";?>
<script type="text/javascript"> function displ(ddd) { if (document.getElementById(ddd).style.display == 'none') {document.getElementById(ddd).style.display = 'block'} else {document.getElementById(ddd).style.display = 'none'} } </script>
<p class="mod"><a href="javascript: displ('var222')">Профиль</a></p>
<div id="var222" style="display: none;">

<p class="bolden">Ваши данные:</p>
<p class="sbk">Ваше имя:<br><span class='name'><?php echo $arr['names'];?></span></p>
<p class="sbk">Ваш e-mail:<br><span class='name'><?php echo $arr['username'];?></span></p>
</div><a href="javascript: displ('var222')"></a></div>
<form novalidate="novalidate" class="form-signin ajax" method="post" action=
"ajax.php">
   
<input type="hidden" name="act" value="logout">
<style>
.button { 
background-color: #000; 
border: none;
color: white; 
padding: 15px 32px; 
text-align: center;
text-decoration: none; 
display: inline-block; 
font-size: 19px;


}

</style>

<input type="submit" class="button" value="Выйти" /></form>
</div><?php else: ?>
 <header>
        <div class="logo">
            <a href="index.html"><img class="graficlogo" src="http://fis.ru/miniformat/31728461.png" alt="Logo"></a>
        </div>



    <nav>
            <div class="topnav"style="width:600px; margin:0 auto;padding-top:2%;" id="myTopnav">
                <a href="index.php">Главная</a>
                <a href="http://h90666nq.beget.tech/klient/index.php">Клиенты</a>
                <a href="predmet/index.php">Предметы</a>
                <a href="http://h90666nq.beget.tech/dogovor/index.php">Договора</a>
                <a href="about.html">Локация</a>
                <a href="services.html">Каталог</a>
            
                <a id="menu"href="#" class="icon">&#9776;</a>
            </div><br><hr>
        </nav>
 <main class="container">
<div class="mydiv"><form class="form-signin ajax" method="post" action="ajax.php">
<p class="zag">Авторизация</p>
<div class="main-error alert alert-error hide"></div>
<input name="username" type="text" class="input-block-level"><br />
<span class="testex">Введите пароль</span><br />
<input name="password" type="password" class="input-block-level"><br />
<input type="hidden" name="act" value="login">
<input type="submit" class="button"  value="Войти">
 </form>

 </main>
 <?php endif; ?>

   <footer>
<div class="footer-container">
<p>Курсовая работа. Разработка информационной системы "Ломбард", студентка группы 4-1ИС, Смирнова А.А. ОГБПОУ техникум им. Ф.В. Чижова. 2019</p>
    </footer>

  <script src="script.js"></script>

<script type="text/javascript" src="jquery-2.0.3.min.js"></script><script type="text/javascript" src="ajax-form.js"></script></body></html>

   

  